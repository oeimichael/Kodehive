﻿using System;
namespace OOPLogical2
{
	public class Movie
	{
		public int No { get; set; }
		public string Nama { get; set; }
		public double Rating { get; set; }
	}
}

