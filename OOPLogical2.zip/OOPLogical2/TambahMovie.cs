﻿using System;
namespace OOPLogical2
{
	public class TambahMovie
	{
		public void AddMovie()
		{
            List<Movie> movies = new List<Movie>();

            Console.Write("No. Movie : ");
            int no = Convert.ToInt32(Console.ReadLine());

            Console.Write("Judul : ");
            string nama = Console.ReadLine();

            Console.Write("Rating awal : ");
            double rating = Convert.ToDouble(Console.ReadLine());

            movies.Add(new Movie() { No = no, Nama = nama, Rating = rating });
        }
	}
}

