﻿using System;

namespace OOPLogical2
{
    class Program
    {
        static void Main(String[] args)
        {
            // Loop terluar
            string program = "lanjut";

            List<Movie> movies = new List<Movie>();

            // Looping program
            while (program != "stop")
            {
                Console.WriteLine("1. Daftar Movie");
                Console.WriteLine("2. Tambah Movie");
                Console.WriteLine("3. Keluar");


                Console.Write("\nPilih menu : ");
                int menuOps = Convert.ToInt32(Console.ReadLine());

                if (menuOps == 1)
                {
                    if (movies.Count == 0)
                    {
                        Console.WriteLine("\nTidak ada movie yang tersedia!\n");

                    }
                    else
                    {
                        // Daftar Movie
                        Console.WriteLine("\nDaftar movie yang tersedia : \n");

                        // Menampilkan data
                        List<Movie> SortedMovie = movies.OrderByDescending(o => o.Rating).ToList();
                        foreach (var x in SortedMovie)
                        {
                            Console.WriteLine($"{x.No}. {x.Nama} - Rating : {x.Rating}");
                        }



                        // Vote option
                        Console.Write("\nVote movie? (y/n) : ");
                        char vote = Convert.ToChar(Console.ReadLine());

                        // Looping vote movie
                        while (vote == 'y')
                        {
                            Console.Write("Pilih nomor movie yang ingin di vote : ");
                            int noMovie = Convert.ToInt32(Console.ReadLine());

                            //// Kondisi movie ditemukan atau tidak
                            if (movies.Count >= noMovie)
                            {
                                foreach (var x in movies)
                                {
                                    if (noMovie == x.No)
                                    {
                                        Console.WriteLine("Movie ditemukan!");
                                        Console.WriteLine($"Judul : {x.Nama}");
                                        Console.WriteLine($"Rating sekarang : {x.Rating}");

                                        Console.WriteLine($"Yakin ingin vote movie {x.Nama}? (y/n)");
                                        char voteMovie = Convert.ToChar(Console.ReadLine());
                                        if (voteMovie == 'y')
                                        {
                                            Console.WriteLine($"Terima kasih telah malakukan vote, kini rating movie dengan judul {x.Nama} telah ditambahkan sebanyak 0.1 ! ");
                                            x.Rating = x.Rating + 0.1;
                                            Console.WriteLine("Rating movie saat ini :");
                                            foreach (var y in SortedMovie)
                                            {
                                                Console.WriteLine($"{y.No}. {y.Nama} - Rating : {y.Rating}");
                                            }
                                        }
                                    }
                                }
                                // Lanjut vote atau tidak?
                                Console.Write("\nVote movie? (y/n) : ");
                                vote = Convert.ToChar(Console.ReadLine());
                            }
                            else
                            {
                                Console.WriteLine("Movie tidak ditemukan!");
                            }
                            
                        }
                        // Looping program
                        Console.WriteLine("Yakin exit program? ketik 'stop' jika ingin keluar program / 'enter' untuk memilih ulang");
                        program = Console.ReadLine();
                    }
                    

                }
                else if (menuOps == 2)
                {
                    char tambahMovie = 'y';

                    while (tambahMovie == 'y')
                    {
                        Console.Write("No. Movie : ");
                        int no = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Judul : ");
                        string nama = Console.ReadLine();

                        Console.Write("Rating awal : ");
                        double rating = Convert.ToDouble(Console.ReadLine());

                        movies.Add(new Movie() { No = no, Nama = nama, Rating = rating });

                        // Looping tambah movie
                        Console.WriteLine("Lanjut tambah movie (y/n)?");
                        tambahMovie = Convert.ToChar(Console.ReadLine());
                    }

                    // Looping program
                    Console.WriteLine("Yakin exit program? ketik 'stop' jika ingin keluar program / 'enter' untuk memilih ulang");
                    program = Console.ReadLine();

                }
                else if (menuOps == 3)
                {
                    Console.Write("Yakin exit program? (y/n)");
                    char exit = Convert.ToChar(Console.ReadLine());
                    if (exit == 'y')
                    {
                        program = "stop";
                    }
                    else
                    {
                        program = "lanjut";
                    }
                }
            }

            


            
            
            



            
        }
    }
}